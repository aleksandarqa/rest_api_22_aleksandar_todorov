package REST_Api_22_Aleksandar_Todorov.stepdefinitions;

import io.cucumber.java.en.Given;

public class ClickUpSteps {

    @Given("Create folder in ClickUp")
    public void createFolder(){
        System.out.println("The first step is executed!");
    }

    @Given("Save its data and verify that the name is correct")
    public void saveTheDate(){
        System.out.println("Our data is correct!");
    }

    @Given("Create a new List in the Folder")
    public void createNewList(){
        System.out.println("New list is created!");
    }

    @Given("Verify the List name is correct")
    public void verifyTheName(){
        System.out.println("The name is correct!");
    }

    @Given("Verify that it is added to the correct folder")
    public void verifyCorrectFolder(){
        System.out.println("The folder is correct!");
    }

    @Given("Create Task in the list automatically generated")
    public void createTask(){
        System.out.println("Create Task in the list automatically generated");
    }

    @Given("After crating the task verify the Task name is correct")
    public void verifyTaskName(){
        System.out.println("The task name is correct!");
    }

    @Given("Remove the Task from the list")
    public void removeTaskFromLIst(){
        System.out.println("The task has been removed!");
    }

    @Given("Fetch the List and verify the Task can't be found anymore")
    public void fetchTheLIst(){
        System.out.println("The list is removed!");
    }
    
}
